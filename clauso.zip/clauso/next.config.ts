import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Clean and minimal — add to this as the app grows
};

export default nextConfig;
