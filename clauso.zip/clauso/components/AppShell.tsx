import { ReactNode } from "react";
import { AppNav } from "./AppNav";

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <div style={{ display: "flex", minHeight: "100dvh" }}>
      <AppNav />

      {/* Main content — offset by sidebar on desktop, padded bottom on mobile for bottom nav */}
      <div
        style={{
          flex: 1,
          minWidth: 0,
          background: "var(--bg-subtle)",
        }}
        className="app-main"
      >
        {children}
      </div>

      <style>{`
        .app-main {
          padding-bottom: 4rem; /* bottom nav clearance on mobile */
        }
        @media (min-width: 768px) {
          .app-main {
            margin-left: 200px;
            padding-bottom: 0;
          }
        }
      `}</style>
    </div>
  );
}
