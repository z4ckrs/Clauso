import { ReactNode } from "react";
import { AppNav } from "./AppNav";
import { SiteFooter } from "@/app/layout";

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <div style={{ display: "flex", minHeight: "100dvh" }}>
      <AppNav />

      <div
        style={{ flex: 1, minWidth: 0, background: "var(--bg-subtle)", display: "flex", flexDirection: "column" }}
        className="app-main"
      >
        <div style={{ flex: 1 }}>{children}</div>
        <SiteFooter />
      </div>

      <style>{`
        .app-main {
          padding-bottom: 4rem;
        }
        @media (min-width: 768px) {
          .app-main {
            margin-left: 200px;
            padding-bottom: 0;
          }
        }
      `}</style>
    </div>
  );
}
