"use client";

import Link from "next/link";
import { ReactNode } from "react";

interface AuthShellProps {
  title: string;
  description: string;
  footer: ReactNode;
  children: ReactNode;
}

export function AuthShell({ title, description, footer, children }: AuthShellProps) {
  return (
    <div
      style={{
        minHeight: "calc(100dvh - 4rem)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "2rem 1.25rem",
        background: "var(--bg-subtle)",
      }}
    >
      <div style={{ width: "100%", maxWidth: "400px" }}>
        {/* Logo */}
        <div style={{ marginBottom: "2rem", textAlign: "center" }}>
          <Link
            href="/"
            style={{
              fontSize: "1.0625rem",
              fontWeight: 700,
              letterSpacing: "-0.03em",
              color: "var(--text)",
            }}
          >
            Clauso
          </Link>
        </div>

        {/* Card */}
        <div
          style={{
            background: "var(--bg)",
            border: "1px solid var(--border)",
            borderRadius: "16px",
            padding: "2rem",
          }}
        >
          <div style={{ marginBottom: "1.75rem" }}>
            <h2 style={{ marginBottom: "0.3rem" }}>{title}</h2>
            <p style={{ fontSize: "0.875rem" }}>{description}</p>
          </div>

          {children}
        </div>

        {/* Footer link */}
        <div style={{ textAlign: "center", marginTop: "1.25rem" }}>
          {footer}
        </div>
      </div>
    </div>
  );
}
