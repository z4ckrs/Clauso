"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const NAV_LINKS = [
  {
    label: "Dashboard",
    href: "/dashboard",
    icon: (
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
        <rect x="1.5" y="1.5" width="5.5" height="5.5" rx="1.5" stroke="currentColor" strokeWidth="1.25" />
        <rect x="9" y="1.5" width="5.5" height="5.5" rx="1.5" stroke="currentColor" strokeWidth="1.25" />
        <rect x="1.5" y="9" width="5.5" height="5.5" rx="1.5" stroke="currentColor" strokeWidth="1.25" />
        <rect x="9" y="9" width="5.5" height="5.5" rx="1.5" stroke="currentColor" strokeWidth="1.25" />
      </svg>
    ),
  },
  {
    label: "Scope Tracker",
    href: "/scope-tracker",
    icon: (
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
        <path d="M2 4h12M2 8h8M2 12h5" stroke="currentColor" strokeWidth="1.25" strokeLinecap="round" />
        <circle cx="12.5" cy="11.5" r="2.5" stroke="currentColor" strokeWidth="1.25" />
        <path d="M14.5 13.5L15.5 14.5" stroke="currentColor" strokeWidth="1.25" strokeLinecap="round" />
      </svg>
    ),
  },
  {
    label: "Sponsor CRM",
    href: "/sponsor-crm",
    icon: (
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
        <path d="M10.5 7A3 3 0 1 0 4.5 7" stroke="currentColor" strokeWidth="1.25" strokeLinecap="round" />
        <path d="M1.5 13.5c0-2.485 1.567-4.5 6-4.5s6 2.015 6 4.5" stroke="currentColor" strokeWidth="1.25" strokeLinecap="round" />
      </svg>
    ),
  },
  {
    label: "Settings",
    href: "/settings",
    icon: (
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
        <circle cx="8" cy="8" r="2" stroke="currentColor" strokeWidth="1.25" />
        <path d="M8 1.5v1M8 13.5v1M1.5 8h1M13.5 8h1M3.4 3.4l.7.7M11.9 11.9l.7.7M3.4 12.6l.7-.7M11.9 4.1l.7-.7" stroke="currentColor" strokeWidth="1.25" strokeLinecap="round" />
      </svg>
    ),
  },
];

export function AppNav() {
  const pathname = usePathname();

  return (
    <>
      {/* ── Desktop Sidebar ── */}
      <aside className="app-sidebar">
        <div style={{ padding: "1.25rem 1rem 1rem" }}>
          <Link
            href="/dashboard"
            style={{
              fontSize: "1rem",
              fontWeight: 700,
              letterSpacing: "-0.03em",
              color: "var(--text)",
              display: "block",
              padding: "0.25rem 0.5rem",
            }}
          >
            Clauso
          </Link>
        </div>

        <nav style={{ padding: "0 0.5rem", flex: 1 }}>
          <ul style={{ listStyle: "none", display: "flex", flexDirection: "column", gap: "2px" }}>
            {NAV_LINKS.map((link) => {
              const active = pathname === link.href;
              return (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: "0.625rem",
                      padding: "0.5rem 0.75rem",
                      borderRadius: "8px",
                      fontSize: "0.875rem",
                      fontWeight: active ? 600 : 400,
                      color: active ? "var(--text)" : "var(--text-muted)",
                      background: active ? "var(--bg-subtle)" : "transparent",
                      transition: "background 0.12s, color 0.12s",
                      textDecoration: "none",
                    }}
                  >
                    <span style={{ color: active ? "var(--accent)" : "var(--text-faint)", flexShrink: 0 }}>
                      {link.icon}
                    </span>
                    {link.label}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* User stub */}
        <div
          style={{
            padding: "0.75rem 1rem",
            borderTop: "1px solid var(--border)",
            display: "flex",
            alignItems: "center",
            gap: "0.625rem",
          }}
        >
          <div
            style={{
              width: "28px",
              height: "28px",
              borderRadius: "50%",
              background: "var(--accent-light)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0,
            }}
          >
            <span style={{ fontSize: "0.6875rem", fontWeight: 700, color: "var(--accent-dark)" }}>
              JD
            </span>
          </div>
          <div style={{ minWidth: 0 }}>
            <div style={{ fontSize: "0.8125rem", fontWeight: 500, color: "var(--text)", lineHeight: 1.2, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
              Jake Designs
            </div>
            <div style={{ fontSize: "0.6875rem", color: "var(--text-faint)", lineHeight: 1.3 }}>
              Tech
            </div>
          </div>
        </div>
      </aside>

      {/* ── Mobile Bottom Nav ── */}
      <nav className="app-bottom-nav">
        {NAV_LINKS.map((link) => {
          const active = pathname === link.href;
          return (
            <Link
              key={link.href}
              href={link.href}
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: "3px",
                padding: "0.5rem 0.75rem",
                color: active ? "var(--accent)" : "var(--text-faint)",
                textDecoration: "none",
                flex: 1,
              }}
            >
              {link.icon}
              <span style={{ fontSize: "0.625rem", fontWeight: active ? 600 : 400, letterSpacing: "0.01em" }}>
                {link.label}
              </span>
            </Link>
          );
        })}
      </nav>

      <style>{`
        .app-sidebar {
          position: fixed;
          top: 0;
          left: 0;
          bottom: 0;
          width: 200px;
          border-right: 1px solid var(--border);
          background: var(--bg);
          display: none;
          flex-direction: column;
          z-index: 40;
        }
        .app-bottom-nav {
          position: fixed;
          bottom: 0;
          left: 0;
          right: 0;
          background: var(--bg);
          border-top: 1px solid var(--border);
          display: flex;
          align-items: center;
          z-index: 40;
          padding-bottom: env(safe-area-inset-bottom);
        }
        @media (min-width: 768px) {
          .app-sidebar { display: flex; }
          .app-bottom-nav { display: none; }
        }
      `}</style>
    </>
  );
}
