export type DealStatus = "active" | "pending" | "completed";

export interface Deal {
  id: string;
  sponsor: string;
  status: DealStatus;
  fee: string;
  deliverables: string[];
  date: string;
}

export interface ScopeAlert {
  id: string;
  dealId: string;
  sponsor: string;
  agreed: string[];
  requesting: string[];
  flaggedItems: string[];
  flaggedAt: string;
}

export interface ActivityItem {
  id: string;
  sponsor: string;
  action: string;
  detail: string;
  time: string;
  type: "flag" | "deal" | "update";
}

/* ─── Deals ────────────────────────────────────── */
export const MOCK_DEALS: Deal[] = [
  {
    id: "deal-1",
    sponsor: "NordVPN",
    status: "active",
    fee: "$4,200",
    deliverables: ["60s mid-roll integration", "Description link 30 days"],
    date: "Mar 14, 2025",
  },
  {
    id: "deal-2",
    sponsor: "Squarespace",
    status: "active",
    fee: "$2,800",
    deliverables: ["30s end-card mention", "Description link 14 days"],
    date: "Mar 8, 2025",
  },
  {
    id: "deal-3",
    sponsor: "Brilliant",
    status: "pending",
    fee: "$3,500",
    deliverables: ["60s mid-roll integration", "Pinned comment"],
    date: "Mar 20, 2025",
  },
  {
    id: "deal-4",
    sponsor: "ExpressVPN",
    status: "completed",
    fee: "$3,100",
    deliverables: ["45s mid-roll integration"],
    date: "Feb 28, 2025",
  },
];

/* ─── Scope Alerts ─────────────────────────────── */
export const MOCK_ALERTS: ScopeAlert[] = [
  {
    id: "alert-1",
    dealId: "deal-1",
    sponsor: "NordVPN",
    agreed: [
      "1x 60s mid-roll integration",
      "Description link for 30 days",
      "No exclusivity",
    ],
    requesting: [
      "1x 60s mid-roll integration",
      "Description link for 30 days",
      "No exclusivity",
      "Instagram story post",
      "TikTok mention",
      "Exclusivity clause — no competitor ads for 60 days",
    ],
    flaggedItems: [
      "Instagram story post",
      "TikTok mention",
      "Exclusivity clause — no competitor ads for 60 days",
    ],
    flaggedAt: "2h ago",
  },
];

/* ─── Activity Feed ────────────────────────────── */
export const MOCK_ACTIVITY: ActivityItem[] = [
  {
    id: "act-1",
    sponsor: "NordVPN",
    action: "Scope creep flagged",
    detail: "3 items outside agreed scope",
    time: "2h ago",
    type: "flag",
  },
  {
    id: "act-2",
    sponsor: "Squarespace",
    action: "Deal activated",
    detail: "Contract signed, deliverables locked in",
    time: "1d ago",
    type: "deal",
  },
  {
    id: "act-3",
    sponsor: "Brilliant",
    action: "Deal created",
    detail: "Awaiting contract confirmation",
    time: "3d ago",
    type: "update",
  },
  {
    id: "act-4",
    sponsor: "ExpressVPN",
    action: "Deal completed",
    detail: "All deliverables delivered and signed off",
    time: "5d ago",
    type: "deal",
  },
];
