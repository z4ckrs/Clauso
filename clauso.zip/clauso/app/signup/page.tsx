"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { AuthShell } from "@/components/AuthShell";

export default function SignupPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    router.push("/onboarding");
  }

  return (
    <AuthShell
      title="Create your account"
      description="Start tracking sponsorship deals in minutes."
      footer={
        <span style={{ fontSize: "0.8125rem", color: "var(--text-faint)" }}>
          Already have an account?{" "}
          <Link href="/login" style={{ color: "var(--accent)", fontWeight: 500 }}>
            Log in
          </Link>
        </span>
      }
    >
      <form onSubmit={handleSubmit}>
        <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
          <div>
            <label className="label" htmlFor="email">
              Email
            </label>
            <input
              id="email"
              type="email"
              className="input"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="email"
            />
          </div>

          <div>
            <label className="label" htmlFor="password">
              Password
            </label>
            <input
              id="password"
              type="password"
              className="input"
              placeholder="At least 8 characters"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="new-password"
            />
          </div>

          <button
            type="submit"
            className="btn-primary"
            style={{
              width: "100%",
              justifyContent: "center",
              marginTop: "0.25rem",
            }}
          >
            Create account
          </button>

          <p
            style={{
              fontSize: "0.75rem",
              color: "var(--text-faint)",
              textAlign: "center",
              lineHeight: 1.6,
            }}
          >
            By signing up, you agree to our{" "}
            <Link
              href="/terms"
              style={{ color: "var(--text-muted)", textDecoration: "underline" }}
            >
              Terms
            </Link>{" "}
            and{" "}
            <Link
              href="/privacy"
              style={{ color: "var(--text-muted)", textDecoration: "underline" }}
            >
              Privacy Policy
            </Link>
            .
          </p>
        </div>
      </form>
    </AuthShell>
  );
}
