"use client";

import { useState } from "react";
import { AppShell } from "@/components/AppShell";

const NICHES = ["Tech", "Gaming", "Finance", "Lifestyle", "Education", "Fitness", "Food", "Travel", "Beauty", "Other"];

export default function SettingsPage() {
  const [channelName, setChannelName] = useState("Jake Designs");
  const [niche, setNiche] = useState("Tech");
  const [email, setEmail] = useState("jake@jakedesigns.co");
  const [saved, setSaved] = useState(false);

  const [notifs, setNotifs] = useState({
    scopeAlerts: true,
    dealUpdates: true,
    weeklyDigest: false,
  });

  function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setSaved(true);
    setTimeout(() => setSaved(false), 2200);
  }

  function toggle(key: keyof typeof notifs) {
    setNotifs((prev) => ({ ...prev, [key]: !prev[key] }));
  }

  return (
    <AppShell>
      <div style={{ padding: "2rem 1.5rem", maxWidth: "600px" }}>
        {/* Header */}
        <div style={{ marginBottom: "2rem" }}>
          <h1 style={{ fontSize: "1.375rem", marginBottom: "0.2rem" }}>Settings</h1>
          <p style={{ fontSize: "0.875rem" }}>Manage your account and preferences.</p>
        </div>

        {/* ── Profile ── */}
        <Section title="Profile" description="Your channel details.">
          <form onSubmit={handleSave}>
            <div style={{ display: "flex", flexDirection: "column", gap: "1.125rem" }}>
              <div>
                <label className="label" htmlFor="channelName">Channel name</label>
                <input
                  id="channelName"
                  className="input"
                  value={channelName}
                  onChange={(e) => setChannelName(e.target.value)}
                />
              </div>

              <div>
                <label className="label">Niche</label>
                <div style={{ display: "flex", flexWrap: "wrap", gap: "0.5rem", marginTop: "0.35rem" }}>
                  {NICHES.map((n) => {
                    const selected = niche === n;
                    return (
                      <button
                        key={n}
                        type="button"
                        onClick={() => setNiche(n)}
                        style={{
                          padding: "0.3rem 0.875rem",
                          borderRadius: "999px",
                          border: selected ? "1.5px solid var(--accent)" : "1.5px solid var(--border)",
                          background: selected ? "var(--accent-light)" : "var(--bg)",
                          color: selected ? "var(--accent-dark)" : "var(--text-muted)",
                          fontSize: "0.8125rem",
                          fontWeight: selected ? 600 : 400,
                          cursor: "pointer",
                          transition: "all 0.12s ease",
                        }}
                      >
                        {n}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="label" htmlFor="email">Email</label>
                <input
                  id="email"
                  type="email"
                  className="input"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>

              <div style={{ display: "flex", alignItems: "center", gap: "0.875rem" }}>
                <button type="submit" className="btn-primary" style={{ fontSize: "0.875rem" }}>
                  Save changes
                </button>
                {saved && (
                  <span style={{ fontSize: "0.8125rem", color: "var(--accent)", fontWeight: 500, display: "flex", alignItems: "center", gap: "0.35rem" }}>
                    <svg width="13" height="13" viewBox="0 0 16 16" fill="none">
                      <circle cx="8" cy="8" r="6.5" stroke="#059669" strokeWidth="1.25" />
                      <path d="M5.5 8.25L7.25 10L10.5 6.5" stroke="#059669" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                    Saved
                  </span>
                )}
              </div>
            </div>
          </form>
        </Section>

        <div style={{ height: "1px", background: "var(--border)", margin: "2rem 0" }} />

        {/* ── Notifications ── */}
        <Section title="Notifications" description="Control what you hear about.">
          <div style={{ display: "flex", flexDirection: "column", gap: "0" }}>
            <ToggleRow
              label="Scope creep alerts"
              description="Get notified when a sponsor requests something outside scope."
              checked={notifs.scopeAlerts}
              onChange={() => toggle("scopeAlerts")}
            />
            <div style={{ height: "1px", background: "var(--border)" }} />
            <ToggleRow
              label="Deal updates"
              description="Status changes on active or pending deals."
              checked={notifs.dealUpdates}
              onChange={() => toggle("dealUpdates")}
            />
            <div style={{ height: "1px", background: "var(--border)" }} />
            <ToggleRow
              label="Weekly digest"
              description="A summary of your deals and activity every Monday."
              checked={notifs.weeklyDigest}
              onChange={() => toggle("weeklyDigest")}
            />
          </div>
        </Section>
      </div>
    </AppShell>
  );
}

/* ─── Section wrapper ───────────────────────────────────── */
function Section({
  title,
  description,
  children,
}: {
  title: string;
  description: string;
  children: React.ReactNode;
}) {
  return (
    <section>
      <div style={{ marginBottom: "1.25rem" }}>
        <h2 style={{ fontSize: "1rem", marginBottom: "0.2rem" }}>{title}</h2>
        <p style={{ fontSize: "0.8125rem" }}>{description}</p>
      </div>
      {children}
    </section>
  );
}

/* ─── Toggle Row ────────────────────────────────────────── */
function ToggleRow({
  label,
  description,
  checked,
  onChange,
}: {
  label: string;
  description: string;
  checked: boolean;
  onChange: () => void;
}) {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: "1.5rem",
        padding: "1rem 0",
      }}
    >
      <div>
        <div style={{ fontSize: "0.875rem", fontWeight: 500, color: "var(--text)", marginBottom: "0.15rem" }}>
          {label}
        </div>
        <p style={{ fontSize: "0.8125rem", lineHeight: 1.4 }}>{description}</p>
      </div>
      <button
        role="switch"
        aria-checked={checked}
        onClick={onChange}
        style={{
          flexShrink: 0,
          width: "40px",
          height: "22px",
          borderRadius: "999px",
          border: "none",
          background: checked ? "var(--accent)" : "var(--border-strong)",
          cursor: "pointer",
          position: "relative",
          transition: "background 0.2s ease",
          padding: 0,
        }}
      >
        <span
          style={{
            display: "block",
            width: "16px",
            height: "16px",
            borderRadius: "50%",
            background: "#fff",
            position: "absolute",
            top: "3px",
            left: checked ? "21px" : "3px",
            transition: "left 0.18s ease",
            boxShadow: "0 1px 3px rgba(0,0,0,0.15)",
          }}
        />
      </button>
    </div>
  );
}
