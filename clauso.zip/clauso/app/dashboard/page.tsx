import type { Metadata } from "next";
import Link from "next/link";
import { AppShell } from "@/components/AppShell";
import {
  MOCK_DEALS,
  MOCK_ALERTS,
  MOCK_ACTIVITY,
  DealStatus,
} from "@/lib/mock-data";

export const metadata: Metadata = { title: "Dashboard" };

export default function DashboardPage() {
  return (
    <AppShell>
      <div style={{ padding: "2rem 1.5rem", maxWidth: "960px" }}>
        {/* Page header */}
        <div style={{ marginBottom: "2rem" }}>
          <h1 style={{ fontSize: "1.375rem", marginBottom: "0.2rem" }}>
            Dashboard
          </h1>
          <p style={{ fontSize: "0.875rem" }}>
            March 2025 &middot; 3 active deals
          </p>
        </div>

        {/* Alert banner — pre-flagged on load */}
        <AlertBanner />

        {/* 3-section grid */}
        <div className="dashboard-grid">
          <ActiveDeals />
          <ActivityFeed />
        </div>
      </div>

      <style>{`
        .dashboard-grid {
          display: grid;
          grid-template-columns: 1fr;
          gap: 1.25rem;
          margin-top: 1.25rem;
        }
        @media (min-width: 900px) {
          .dashboard-grid {
            grid-template-columns: 1fr 340px;
          }
        }
      `}</style>
    </AppShell>
  );
}

/* ─── Alert Banner ──────────────────────────────────────── */
function AlertBanner() {
  const alert = MOCK_ALERTS[0];

  return (
    <div
      style={{
        border: "1.5px solid var(--danger)",
        borderRadius: "12px",
        background: "var(--danger-light)",
        padding: "1rem 1.25rem",
        display: "flex",
        alignItems: "flex-start",
        gap: "0.75rem",
        marginBottom: "0.25rem",
      }}
    >
      {/* Icon */}
      <div
        style={{
          width: "32px",
          height: "32px",
          borderRadius: "8px",
          background: "#fff",
          border: "1px solid rgba(239,68,68,0.2)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexShrink: 0,
        }}
      >
        <svg width="15" height="15" viewBox="0 0 16 16" fill="none">
          <path d="M8 2L14.5 13.5H1.5L8 2Z" stroke="#EF4444" strokeWidth="1.4" strokeLinejoin="round" />
          <path d="M8 7V9.5" stroke="#EF4444" strokeWidth="1.4" strokeLinecap="round" />
          <circle cx="8" cy="11.5" r="0.75" fill="#EF4444" />
        </svg>
      </div>

      {/* Text */}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div
          style={{
            fontSize: "0.875rem",
            fontWeight: 600,
            color: "var(--danger)",
            marginBottom: "0.2rem",
          }}
        >
          Scope creep detected &mdash; {alert.sponsor}
        </div>
        <p style={{ fontSize: "0.8125rem", color: "#b91c1c", lineHeight: 1.5 }}>
          {alert.flaggedItems.length} items outside your agreed contract:{" "}
          {alert.flaggedItems.join(", ")}.
        </p>
      </div>

      {/* CTA */}
      <Link
        href="/scope-tracker"
        style={{
          flexShrink: 0,
          fontSize: "0.8125rem",
          fontWeight: 600,
          color: "var(--danger)",
          border: "1.5px solid rgba(239,68,68,0.35)",
          borderRadius: "8px",
          padding: "0.3rem 0.75rem",
          background: "#fff",
          whiteSpace: "nowrap",
          transition: "background 0.12s",
          textDecoration: "none",
        }}
      >
        Review
      </Link>
    </div>
  );
}

/* ─── Active Deals ──────────────────────────────────────── */
function ActiveDeals() {
  const statusStyles: Record<DealStatus, { bg: string; color: string; label: string }> = {
    active: { bg: "var(--accent-light)", color: "var(--accent-dark)", label: "Active" },
    pending: { bg: "#FEF9C3", color: "#854D0E", label: "Pending" },
    completed: { bg: "var(--bg-subtle)", color: "var(--text-faint)", label: "Completed" },
  };

  return (
    <section>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          marginBottom: "0.875rem",
        }}
      >
        <h2 style={{ fontSize: "0.9375rem" }}>Active deals</h2>
        <Link
          href="/sponsor-crm"
          style={{ fontSize: "0.8125rem", color: "var(--accent)", fontWeight: 500, textDecoration: "none" }}
        >
          View all
        </Link>
      </div>

      <div
        style={{
          background: "var(--bg)",
          border: "1px solid var(--border)",
          borderRadius: "12px",
          overflow: "hidden",
        }}
      >
        {MOCK_DEALS.map((deal, i) => {
          const s = statusStyles[deal.status];
          const hasScopeAlert = MOCK_ALERTS.some((a) => a.dealId === deal.id);
          return (
            <div
              key={deal.id}
              style={{
                display: "flex",
                alignItems: "center",
                padding: "0.875rem 1.125rem",
                borderTop: i > 0 ? "1px solid var(--border)" : "none",
                gap: "0.875rem",
              }}
            >
              {/* Sponsor initial */}
              <div
                style={{
                  width: "34px",
                  height: "34px",
                  borderRadius: "8px",
                  background: "var(--bg-subtle)",
                  border: "1px solid var(--border)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  flexShrink: 0,
                  fontSize: "0.75rem",
                  fontWeight: 700,
                  color: "var(--text-muted)",
                  letterSpacing: "-0.01em",
                }}
              >
                {deal.sponsor.slice(0, 2).toUpperCase()}
              </div>

              {/* Name + deliverables */}
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", marginBottom: "0.15rem" }}>
                  <span style={{ fontSize: "0.875rem", fontWeight: 600, color: "var(--text)" }}>
                    {deal.sponsor}
                  </span>
                  {hasScopeAlert && (
                    <span
                      style={{
                        width: "6px",
                        height: "6px",
                        borderRadius: "50%",
                        background: "var(--danger)",
                        display: "inline-block",
                        flexShrink: 0,
                      }}
                      title="Scope creep flagged"
                    />
                  )}
                </div>
                <div
                  style={{
                    fontSize: "0.75rem",
                    color: "var(--text-faint)",
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    whiteSpace: "nowrap",
                  }}
                >
                  {deal.deliverables[0]}
                  {deal.deliverables.length > 1 && ` +${deal.deliverables.length - 1} more`}
                </div>
              </div>

              {/* Fee + status */}
              <div style={{ textAlign: "right", flexShrink: 0 }}>
                <div style={{ fontSize: "0.875rem", fontWeight: 600, color: "var(--text)", marginBottom: "0.2rem" }}>
                  {deal.fee}
                </div>
                <span
                  style={{
                    display: "inline-block",
                    padding: "0.1rem 0.5rem",
                    borderRadius: "999px",
                    background: s.bg,
                    color: s.color,
                    fontSize: "0.6875rem",
                    fontWeight: 600,
                  }}
                >
                  {s.label}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}

/* ─── Activity Feed ─────────────────────────────────────── */
function ActivityFeed() {
  const typeIcon = (type: string) => {
    if (type === "flag")
      return (
        <div style={{ width: "28px", height: "28px", borderRadius: "8px", background: "var(--danger-light)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
          <svg width="12" height="12" viewBox="0 0 16 16" fill="none">
            <path d="M8 2L14.5 13.5H1.5L8 2Z" stroke="#EF4444" strokeWidth="1.4" strokeLinejoin="round" />
            <path d="M8 7V9.5" stroke="#EF4444" strokeWidth="1.4" strokeLinecap="round" />
            <circle cx="8" cy="11.5" r="0.75" fill="#EF4444" />
          </svg>
        </div>
      );
    if (type === "deal")
      return (
        <div style={{ width: "28px", height: "28px", borderRadius: "8px", background: "var(--accent-light)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
          <svg width="12" height="12" viewBox="0 0 16 16" fill="none">
            <circle cx="8" cy="8" r="6.5" stroke="#059669" strokeWidth="1.25" />
            <path d="M5.5 8.25L7.25 10L10.5 6.5" stroke="#059669" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      );
    return (
      <div style={{ width: "28px", height: "28px", borderRadius: "8px", background: "var(--bg-subtle)", border: "1px solid var(--border)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
        <svg width="12" height="12" viewBox="0 0 16 16" fill="none">
          <circle cx="8" cy="8" r="2" stroke="var(--text-faint)" strokeWidth="1.25" />
          <path d="M8 1.5v2M8 12.5v2M1.5 8h2M12.5 8h2" stroke="var(--text-faint)" strokeWidth="1.25" strokeLinecap="round" />
        </svg>
      </div>
    );
  };

  return (
    <section>
      <h2 style={{ fontSize: "0.9375rem", marginBottom: "0.875rem" }}>
        Recent activity
      </h2>

      <div
        style={{
          background: "var(--bg)",
          border: "1px solid var(--border)",
          borderRadius: "12px",
          overflow: "hidden",
        }}
      >
        {MOCK_ACTIVITY.map((item, i) => (
          <div
            key={item.id}
            style={{
              display: "flex",
              alignItems: "flex-start",
              gap: "0.75rem",
              padding: "0.875rem 1.125rem",
              borderTop: i > 0 ? "1px solid var(--border)" : "none",
            }}
          >
            {typeIcon(item.type)}
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", gap: "0.5rem", marginBottom: "0.15rem" }}>
                <span style={{ fontSize: "0.8125rem", fontWeight: 600, color: "var(--text)" }}>
                  {item.sponsor}
                </span>
                <span style={{ fontSize: "0.6875rem", color: "var(--text-faint)", flexShrink: 0 }}>
                  {item.time}
                </span>
              </div>
              <div style={{ fontSize: "0.75rem", color: "var(--text-faint)", lineHeight: 1.4 }}>
                {item.action} &middot; {item.detail}
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
