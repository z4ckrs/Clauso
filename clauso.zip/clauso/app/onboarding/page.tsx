"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

const NICHES = [
  "Tech",
  "Gaming",
  "Finance",
  "Lifestyle",
  "Education",
  "Fitness",
  "Food",
  "Travel",
  "Beauty",
  "Other",
];

export default function OnboardingPage() {
  const router = useRouter();
  const [channelName, setChannelName] = useState("");
  const [niche, setNiche] = useState("");

  const isValid = channelName.trim().length > 0 && niche.length > 0;

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!isValid) return;
    router.push("/dashboard");
  }

  return (
    <div
      style={{
        minHeight: "100dvh",
        display: "flex",
        alignItems: "flex-start",
        justifyContent: "center",
        padding: "2rem 1.25rem 3rem",
        background: "var(--bg-subtle)",
      }}
    >
      <div style={{ width: "100%", maxWidth: "440px" }}>
        {/* Logo */}
        <div style={{ textAlign: "center", marginBottom: "1.5rem" }}>
          <span
            style={{
              fontSize: "1.0625rem",
              fontWeight: 700,
              letterSpacing: "-0.03em",
              color: "var(--text)",
            }}
          >
            Clauso
          </span>
        </div>

        {/* Card */}
        <div
          style={{
            background: "var(--bg)",
            border: "1px solid var(--border)",
            borderRadius: "16px",
            padding: "1.5rem",
          }}
        >
          {/* Header */}
          <div style={{ marginBottom: "1.5rem" }}>
            <div
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: "0.35rem",
                padding: "0.2rem 0.6rem",
                background: "var(--accent-light)",
                borderRadius: "999px",
                marginBottom: "0.75rem",
              }}
            >
              <span
                style={{
                  fontSize: "0.6875rem",
                  fontWeight: 600,
                  color: "var(--accent-dark)",
                  letterSpacing: "0.04em",
                }}
              >
                Step 1 of 1
              </span>
            </div>
            <h2 style={{ marginBottom: "0.3rem" }}>Set up your workspace</h2>
            <p style={{ fontSize: "0.875rem" }}>
              Two quick details to get your account ready.
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit}>
            <div style={{ display: "flex", flexDirection: "column", gap: "1.125rem" }}>
              {/* Channel name */}
              <div>
                <label className="label" htmlFor="channelName">
                  Channel name
                </label>
                <input
                  id="channelName"
                  type="text"
                  className="input"
                  placeholder="Your YouTube channel name"
                  value={channelName}
                  onChange={(e) => setChannelName(e.target.value)}
                  autoFocus
                />
              </div>

              {/* Niche */}
              <div>
                <label className="label" htmlFor="niche">
                  Your niche
                </label>
                <div
                  style={{
                    display: "flex",
                    flexWrap: "wrap",
                    gap: "0.4rem",
                    marginTop: "0.35rem",
                  }}
                >
                  {NICHES.map((n) => {
                    const selected = niche === n;
                    return (
                      <button
                        key={n}
                        type="button"
                        onClick={() => setNiche(n)}
                        style={{
                          padding: "0.25rem 0.75rem",
                          borderRadius: "999px",
                          border: selected
                            ? "1.5px solid var(--accent)"
                            : "1.5px solid var(--border)",
                          background: selected ? "var(--accent-light)" : "var(--bg)",
                          color: selected ? "var(--accent-dark)" : "var(--text-muted)",
                          fontSize: "0.8125rem",
                          fontWeight: selected ? 600 : 400,
                          cursor: "pointer",
                          transition: "all 0.12s ease",
                        }}
                      >
                        {n}
                      </button>
                    );
                  })}
                </div>
              </div>

              <button
                type="submit"
                disabled={!isValid}
                className="btn-primary"
                style={{
                  width: "100%",
                  justifyContent: "center",
                  marginTop: "0.25rem",
                  opacity: isValid ? 1 : 0.4,
                  cursor: isValid ? "pointer" : "not-allowed",
                  transition: "opacity 0.15s",
                }}
              >
                Go to dashboard
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
