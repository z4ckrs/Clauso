import Link from "next/link";

export default function NotFound() {
  return (
    <div
      style={{
        minHeight: "calc(100dvh - 6rem)",
        display: "flex",
        alignItems: "center",
        padding: "4rem 1.5rem",
      }}
    >
      <div style={{ maxWidth: "480px" }}>
        <div
          style={{
            fontSize: "0.6875rem",
            fontWeight: 700,
            letterSpacing: "0.12em",
            textTransform: "uppercase",
            color: "var(--text-faint)",
            marginBottom: "1.25rem",
          }}
        >
          404
        </div>

        <h1
          style={{
            fontSize: "clamp(1.75rem, 4vw, 2.25rem)",
            marginBottom: "0.875rem",
          }}
        >
          This page does not exist.
        </h1>

        <p
          style={{
            fontSize: "1rem",
            color: "var(--text-muted)",
            lineHeight: 1.65,
            marginBottom: "2rem",
            maxWidth: "360px",
          }}
        >
          The link you followed is broken or the page has moved. Check the URL or head back to somewhere real.
        </p>

        <div style={{ display: "flex", gap: "0.75rem", flexWrap: "wrap" }}>
          <Link href="/dashboard" className="btn-primary" style={{ fontSize: "0.875rem" }}>
            Go to dashboard
          </Link>
          <Link href="/" className="btn-ghost" style={{ fontSize: "0.875rem" }}>
            Back to home
          </Link>
        </div>
      </div>
    </div>
  );
}
