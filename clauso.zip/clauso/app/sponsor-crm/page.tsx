import type { Metadata } from "next";
import { AppShell } from "@/components/AppShell";

export const metadata: Metadata = { title: "Sponsor CRM" };

type Status = "active" | "pending" | "completed";

const SPONSORS: {
  id: string;
  name: string;
  status: Status;
  deal: string;
  fee: string;
  lastActivity: string;
}[] = [
  {
    id: "s1",
    name: "NordVPN",
    status: "active",
    deal: "60s mid-roll integration — March video",
    fee: "$4,200",
    lastActivity: "2h ago",
  },
  {
    id: "s2",
    name: "Squarespace",
    status: "active",
    deal: "30s end-card mention — March video",
    fee: "$2,800",
    lastActivity: "1d ago",
  },
  {
    id: "s3",
    name: "Raycon",
    status: "pending",
    deal: "45s mid-roll integration — April video",
    fee: "$3,000",
    lastActivity: "3d ago",
  },
];

const STATUS: Record<Status, { bg: string; color: string; label: string }> = {
  active: { bg: "var(--accent-light)", color: "var(--accent-dark)", label: "Active" },
  pending: { bg: "#FEF9C3", color: "#854D0E", label: "Pending" },
  completed: { bg: "var(--bg-subtle)", color: "var(--text-faint)", label: "Completed" },
};

export default function SponsorCRMPage() {
  return (
    <AppShell>
      <div style={{ padding: "2rem 1.5rem", maxWidth: "860px" }}>
        {/* Header */}
        <div
          style={{
            display: "flex",
            alignItems: "flex-end",
            justifyContent: "space-between",
            gap: "1rem",
            marginBottom: "2rem",
            flexWrap: "wrap",
          }}
        >
          <div>
            <h1 style={{ fontSize: "1.375rem", marginBottom: "0.2rem" }}>Sponsors</h1>
            <p style={{ fontSize: "0.875rem" }}>
              {SPONSORS.length} sponsors &middot; 2 active deals
            </p>
          </div>
          <button className="btn-primary" style={{ fontSize: "0.875rem" }}>
            Add sponsor
          </button>
        </div>

        {/* Table */}
        <div
          style={{
            background: "var(--bg)",
            border: "1px solid var(--border)",
            borderRadius: "12px",
            overflow: "hidden",
          }}
        >
          {/* Column headers */}
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "1fr 1fr auto",
              padding: "0.625rem 1.25rem",
              borderBottom: "1px solid var(--border)",
              background: "var(--bg-subtle)",
              gap: "1rem",
            }}
            className="crm-header"
          >
            <span style={{ fontSize: "0.6875rem", fontWeight: 700, color: "var(--text-faint)", letterSpacing: "0.08em", textTransform: "uppercase" }}>
              Sponsor
            </span>
            <span
              style={{ fontSize: "0.6875rem", fontWeight: 700, color: "var(--text-faint)", letterSpacing: "0.08em", textTransform: "uppercase" }}
              className="crm-deal-col"
            >
              Deal
            </span>
            <span style={{ fontSize: "0.6875rem", fontWeight: 700, color: "var(--text-faint)", letterSpacing: "0.08em", textTransform: "uppercase", textAlign: "right" }}>
              Last activity
            </span>
          </div>

          {/* Rows */}
          {SPONSORS.map((s, i) => {
            const st = STATUS[s.status];
            return (
              <div
                key={s.id}
                style={{
                  display: "grid",
                  gridTemplateColumns: "1fr 1fr auto",
                  padding: "1rem 1.25rem",
                  borderTop: i > 0 ? "1px solid var(--border)" : "none",
                  gap: "1rem",
                  alignItems: "center",
                  cursor: "pointer",
                  transition: "background 0.1s",
                }}
                className="crm-row"
              >
                {/* Sponsor name + status */}
                <div style={{ display: "flex", alignItems: "center", gap: "0.75rem", minWidth: 0 }}>
                  <div
                    style={{
                      width: "36px",
                      height: "36px",
                      borderRadius: "9px",
                      background: "var(--bg-subtle)",
                      border: "1px solid var(--border)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      fontSize: "0.75rem",
                      fontWeight: 700,
                      color: "var(--text-muted)",
                      flexShrink: 0,
                    }}
                  >
                    {s.name.slice(0, 2).toUpperCase()}
                  </div>
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontSize: "0.875rem", fontWeight: 600, color: "var(--text)", marginBottom: "0.2rem" }}>
                      {s.name}
                    </div>
                    <span
                      style={{
                        display: "inline-block",
                        padding: "0.1rem 0.5rem",
                        borderRadius: "999px",
                        background: st.bg,
                        color: st.color,
                        fontSize: "0.6875rem",
                        fontWeight: 600,
                      }}
                    >
                      {st.label}
                    </span>
                  </div>
                </div>

                {/* Deal summary */}
                <div style={{ minWidth: 0 }} className="crm-deal-col">
                  <div
                    style={{
                      fontSize: "0.8125rem",
                      color: "var(--text-muted)",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                      whiteSpace: "nowrap",
                    }}
                  >
                    {s.deal}
                  </div>
                  <div style={{ fontSize: "0.75rem", color: "var(--text-faint)", marginTop: "0.15rem" }}>
                    {s.fee}
                  </div>
                </div>

                {/* Last activity */}
                <div style={{ textAlign: "right" }}>
                  <span style={{ fontSize: "0.8125rem", color: "var(--text-faint)", whiteSpace: "nowrap" }}>
                    {s.lastActivity}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <style>{`
        .crm-row:hover { background: var(--bg-subtle); }
        @media (max-width: 600px) {
          .crm-header,
          .crm-row {
            grid-template-columns: 1fr auto !important;
          }
          .crm-deal-col { display: none !important; }
        }
      `}</style>
    </AppShell>
  );
}
