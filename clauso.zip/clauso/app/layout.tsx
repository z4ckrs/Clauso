import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-inter",
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "Clauso",
    template: "%s | Clauso",
  },
  description: "Sponsorship deal management for YouTube creators.",
  metadataBase: new URL("https://clauso.app"),
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={inter.variable}>
      <body>
        <div className="flex flex-col min-h-dvh">
          <main className="flex-1">{children}</main>
        </div>
      </body>
    </html>
  );
}

export function SiteFooter() {
  const year = new Date().getFullYear();

  return (
    <footer
      style={{
        borderTop: "1px solid var(--border)",
        padding: "1.25rem 0",
      }}
    >
      <div className="page-container">
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            flexWrap: "wrap",
            gap: "0.75rem",
          }}
        >
          <span style={{ fontSize: "0.8125rem", color: "var(--text-faint)" }}>
            &copy; {year} Clauso. All rights reserved.
          </span>
          <nav style={{ display: "flex", gap: "1.25rem" }}>
            {[
              { label: "Terms", href: "/terms" },
              { label: "Privacy", href: "/privacy" },
            ].map((link) => (
              <a
                key={link.href}
                href={link.href}
                style={{ fontSize: "0.8125rem", color: "var(--text-faint)", transition: "color 0.15s" }}
              >
                {link.label}
              </a>
            ))}
          </nav>
        </div>
      </div>
    </footer>
  );
}
