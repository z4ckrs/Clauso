import type { Metadata } from "next";
import Link from "next/link";
import { AppShell } from "@/components/AppShell";
import { MOCK_ALERTS } from "@/lib/mock-data";

export const metadata: Metadata = { title: "Scope Tracker" };

export default function ScopeTrackerPage() {
  const deal = MOCK_ALERTS[0];

  return (
    <AppShell>
      <div style={{ padding: "2rem 1.5rem", maxWidth: "960px" }}>
        {/* Page header */}
        <div
          style={{
            display: "flex",
            alignItems: "flex-start",
            justifyContent: "space-between",
            gap: "1rem",
            marginBottom: "2rem",
            flexWrap: "wrap",
          }}
        >
          <div>
            <h1 style={{ fontSize: "1.375rem", marginBottom: "0.2rem" }}>
              Scope Tracker
            </h1>
            <p style={{ fontSize: "0.875rem" }}>
              Comparing agreed scope against what the sponsor is asking for.
            </p>
          </div>
          <Link
            href="/dashboard"
            style={{
              fontSize: "0.8125rem",
              color: "var(--text-muted)",
              border: "1px solid var(--border)",
              borderRadius: "8px",
              padding: "0.4rem 0.875rem",
              fontWeight: 500,
              textDecoration: "none",
              whiteSpace: "nowrap",
              background: "var(--bg)",
            }}
          >
            Back to dashboard
          </Link>
        </div>

        {/* Deal header card */}
        <DealHeader sponsor={deal.sponsor} flagCount={deal.flaggedItems.length} />

        {/* Core comparison */}
        <ScopeComparison deal={deal} />

        {/* Summary strip */}
        <ScopeSummary flaggedItems={deal.flaggedItems} />
      </div>
    </AppShell>
  );
}

/* ─── Deal Header ───────────────────────────────────────── */
function DealHeader({ sponsor, flagCount }: { sponsor: string; flagCount: number }) {
  return (
    <div
      style={{
        background: "var(--bg)",
        border: "1px solid var(--border)",
        borderRadius: "12px",
        padding: "1rem 1.25rem",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: "1rem",
        marginBottom: "1.25rem",
        flexWrap: "wrap",
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
        <div
          style={{
            width: "38px",
            height: "38px",
            borderRadius: "10px",
            background: "var(--bg-subtle)",
            border: "1px solid var(--border)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: "0.8125rem",
            fontWeight: 700,
            color: "var(--text-muted)",
            flexShrink: 0,
          }}
        >
          {sponsor.slice(0, 2).toUpperCase()}
        </div>
        <div>
          <div style={{ fontSize: "0.9375rem", fontWeight: 600, color: "var(--text)", marginBottom: "0.1rem" }}>
            {sponsor}
          </div>
          <div style={{ fontSize: "0.75rem", color: "var(--text-faint)" }}>
            March Integration &middot; $4,200 &middot; Signed Feb 14
          </div>
        </div>
      </div>

      <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
        <span
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: "0.35rem",
            padding: "0.3rem 0.75rem",
            background: "var(--danger-light)",
            color: "var(--danger)",
            fontSize: "0.8125rem",
            fontWeight: 600,
            borderRadius: "999px",
          }}
        >
          <svg width="12" height="12" viewBox="0 0 16 16" fill="none">
            <path d="M8 2L14.5 13.5H1.5L8 2Z" stroke="#EF4444" strokeWidth="1.4" strokeLinejoin="round" />
            <path d="M8 7V9" stroke="#EF4444" strokeWidth="1.4" strokeLinecap="round" />
            <circle cx="8" cy="11" r="0.75" fill="#EF4444" />
          </svg>
          {flagCount} items flagged
        </span>
        <span
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: "0.35rem",
            padding: "0.3rem 0.75rem",
            background: "var(--accent-light)",
            color: "var(--accent-dark)",
            fontSize: "0.8125rem",
            fontWeight: 600,
            borderRadius: "999px",
          }}
        >
          Active
        </span>
      </div>
    </div>
  );
}

/* ─── Scope Comparison ──────────────────────────────────── */
function ScopeComparison({ deal }: { deal: typeof MOCK_ALERTS[0] }) {
  const flagSet = new Set(deal.flaggedItems);

  return (
    <div
      style={{
        border: "1px solid var(--border)",
        borderRadius: "12px",
        overflow: "hidden",
        background: "var(--bg)",
        marginBottom: "1.25rem",
      }}
    >
      {/* Column headers */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          borderBottom: "1px solid var(--border)",
        }}
      >
        <div
          style={{
            padding: "0.875rem 1.25rem",
            borderRight: "1px solid var(--border)",
            background: "var(--bg-subtle)",
          }}
        >
          <div style={{ fontSize: "0.6875rem", fontWeight: 700, color: "var(--text-faint)", letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: "0.2rem" }}>
            What you agreed to
          </div>
          <div style={{ fontSize: "0.8125rem", color: "var(--text-muted)" }}>
            {deal.agreed.length} deliverables in contract
          </div>
        </div>
        <div
          style={{
            padding: "0.875rem 1.25rem",
            background: "#FFF5F5",
          }}
        >
          <div style={{ fontSize: "0.6875rem", fontWeight: 700, color: "var(--danger)", letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: "0.2rem", opacity: 0.7 }}>
            What they are asking for
          </div>
          <div style={{ fontSize: "0.8125rem", color: "var(--danger)", fontWeight: 500 }}>
            {deal.requesting.length} deliverables requested &mdash; {deal.flaggedItems.length} outside scope
          </div>
        </div>
      </div>

      {/* Row-by-row comparison */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr" }}>
        {/* Agreed column */}
        <div
          style={{
            borderRight: "1px solid var(--border)",
            padding: "0.5rem 0",
          }}
        >
          {deal.agreed.map((item, i) => (
            <div
              key={i}
              style={{
                display: "flex",
                alignItems: "flex-start",
                gap: "0.625rem",
                padding: "0.75rem 1.25rem",
                borderBottom: i < deal.agreed.length - 1 ? "1px solid var(--border)" : "none",
              }}
            >
              <svg width="15" height="15" viewBox="0 0 16 16" fill="none" style={{ flexShrink: 0, marginTop: "1px" }}>
                <circle cx="8" cy="8" r="6.5" stroke="#059669" strokeWidth="1.25" />
                <path d="M5.5 8.25L7.25 10L10.5 6.5" stroke="#059669" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              <span style={{ fontSize: "0.875rem", color: "var(--text)", lineHeight: 1.5 }}>
                {item}
              </span>
            </div>
          ))}
        </div>

        {/* Requesting column */}
        <div style={{ padding: "0.5rem 0" }}>
          {deal.requesting.map((item, i) => {
            const flagged = flagSet.has(item);
            return (
              <div
                key={i}
                style={{
                  display: "flex",
                  alignItems: "flex-start",
                  gap: "0.625rem",
                  padding: "0.75rem 1.25rem",
                  borderBottom: i < deal.requesting.length - 1 ? "1px solid var(--border)" : "none",
                  background: flagged ? "#FFF5F5" : "transparent",
                  transition: "background 0.1s",
                }}
              >
                {flagged ? (
                  <svg width="15" height="15" viewBox="0 0 16 16" fill="none" style={{ flexShrink: 0, marginTop: "1px" }}>
                    <circle cx="8" cy="8" r="6.5" stroke="#EF4444" strokeWidth="1.25" />
                    <path d="M8 5.5V8.5" stroke="#EF4444" strokeWidth="1.25" strokeLinecap="round" />
                    <circle cx="8" cy="10.5" r="0.75" fill="#EF4444" />
                  </svg>
                ) : (
                  <svg width="15" height="15" viewBox="0 0 16 16" fill="none" style={{ flexShrink: 0, marginTop: "1px" }}>
                    <circle cx="8" cy="8" r="6.5" stroke="#059669" strokeWidth="1.25" />
                    <path d="M5.5 8.25L7.25 10L10.5 6.5" stroke="#059669" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                )}
                <span
                  style={{
                    fontSize: "0.875rem",
                    color: flagged ? "var(--danger)" : "var(--text)",
                    fontWeight: flagged ? 500 : 400,
                    lineHeight: 1.5,
                  }}
                >
                  {item}
                </span>
                {flagged && (
                    <span
                      style={{
                        marginLeft: "auto",
                        flexShrink: 0,
                        fontSize: "0.625rem",
                        fontWeight: 700,
                        color: "var(--danger)",
                        background: "var(--danger-light)",
                        borderRadius: "4px",
                        padding: "0.15rem 0.4rem",
                        letterSpacing: "0.04em",
                        textTransform: "uppercase",
                        alignSelf: "center",
                        whiteSpace: "nowrap",
                      }}
                    >
                      Flagged
                    </span>
                  )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

/* ─── Summary Strip ─────────────────────────────────────── */
function ScopeSummary({ flaggedItems }: { flaggedItems: string[] }) {
  return (
    <div
      style={{
        border: "1.5px solid var(--danger)",
        borderRadius: "12px",
        background: "var(--danger-light)",
        padding: "1.25rem",
        display: "flex",
        flexDirection: "column",
        gap: "0.875rem",
      }}
    >
      <div style={{ display: "flex", alignItems: "flex-start", gap: "0.75rem" }}>
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" style={{ flexShrink: 0, marginTop: "2px" }}>
          <path d="M8 2L14.5 13.5H1.5L8 2Z" stroke="#EF4444" strokeWidth="1.4" strokeLinejoin="round" />
          <path d="M8 7V9" stroke="#EF4444" strokeWidth="1.4" strokeLinecap="round" />
          <circle cx="8" cy="11" r="0.75" fill="#EF4444" />
        </svg>
        <div>
          <div style={{ fontSize: "0.875rem", fontWeight: 700, color: "var(--danger)", marginBottom: "0.35rem" }}>
            {flaggedItems.length} items were not part of your agreement.
          </div>
          <ul style={{ listStyle: "none", display: "flex", flexDirection: "column", gap: "0.3rem" }}>
            {flaggedItems.map((item, i) => (
              <li key={i} style={{ fontSize: "0.8125rem", color: "#b91c1c", display: "flex", alignItems: "center", gap: "0.4rem" }}>
                <span style={{ width: "4px", height: "4px", borderRadius: "50%", background: "#b91c1c", display: "inline-block", flexShrink: 0 }} />
                {item}
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div
        style={{
          display: "flex",
          gap: "0.75rem",
          flexWrap: "wrap",
          borderTop: "1px solid rgba(239,68,68,0.2)",
          paddingTop: "0.875rem",
        }}
      >
        <button
          className="btn-primary"
          style={{ fontSize: "0.8125rem", padding: "0.4rem 1rem" }}
        >
          Log a revision charge
        </button>
        <button
          style={{
            fontSize: "0.8125rem",
            fontWeight: 500,
            color: "var(--danger)",
            background: "#fff",
            border: "1.5px solid rgba(239,68,68,0.3)",
            borderRadius: "8px",
            padding: "0.4rem 1rem",
            cursor: "pointer",
          }}
        >
          Mark as disputed
        </button>
      </div>
    </div>
  );
}
