import Link from "next/link";
import type { Metadata } from "next";
import { SiteFooter } from "@/app/layout";

export const metadata: Metadata = {
  title: "Clauso",
  description:
    "Stop sponsor scope creep before it starts. Clauso helps YouTube creators track what they agreed to and flag when sponsors ask for more.",
};

export default function LandingPage() {
  return (
    <>
      <SiteNav />
      <HeroSection />
      <HowItWorksSection />
      <BottomCTA />
      <SiteFooter />
    </>
  );
}

/* ─── Nav ───────────────────────────────────────────────── */
function SiteNav() {
  return (
    <header
      style={{
        borderBottom: "1px solid var(--border)",
        position: "sticky",
        top: 0,
        background: "var(--bg)",
        zIndex: 50,
      }}
    >
      <div
        className="page-container"
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          height: "3.5rem",
        }}
      >
        <span
          style={{
            fontSize: "1rem",
            fontWeight: 700,
            letterSpacing: "-0.03em",
            color: "var(--text)",
          }}
        >
          Clauso
        </span>
        <Link
          href="/login"
          style={{
            fontSize: "0.875rem",
            fontWeight: 500,
            color: "var(--text-muted)",
            transition: "color 0.15s",
          }}
          onMouseEnter={(e) =>
            ((e.target as HTMLElement).style.color = "var(--text)")
          }
          onMouseLeave={(e) =>
            ((e.target as HTMLElement).style.color = "var(--text-muted)")
          }
        >
          Log in
        </Link>
      </div>
    </header>
  );
}

/* ─── Hero ──────────────────────────────────────────────── */
function HeroSection() {
  return (
    <section
      style={{
        padding: "5rem 0 4rem",
        borderBottom: "1px solid var(--border)",
        background: "var(--bg)",
      }}
    >
      <div className="page-container">
        {/* Asymmetric grid: 52% text / 48% demo */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr",
            gap: "3rem",
            alignItems: "start",
          }}
          className="hero-grid"
        >
          {/* Left: Headline + context + CTA */}
          <div style={{ maxWidth: "560px" }}>
            <div
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: "0.4rem",
                padding: "0.25rem 0.75rem",
                background: "var(--accent-light)",
                borderRadius: "999px",
                marginBottom: "1.5rem",
              }}
            >
              <span
                style={{
                  width: "6px",
                  height: "6px",
                  borderRadius: "50%",
                  background: "var(--accent)",
                  display: "block",
                  flexShrink: 0,
                }}
              />
              <span
                style={{
                  fontSize: "0.75rem",
                  fontWeight: 600,
                  color: "var(--accent-dark)",
                  letterSpacing: "0.02em",
                }}
              >
                For YouTube creators
              </span>
            </div>

            <h1
              style={{
                marginBottom: "1.25rem",
              }}
            >
              Know exactly what you agreed to.
            </h1>

            <p
              style={{
                fontSize: "1.0625rem",
                lineHeight: "1.7",
                color: "var(--text-muted)",
                marginBottom: "2rem",
                maxWidth: "440px",
              }}
            >
              Clauso flags scope creep the moment a sponsor asks for more than what you signed.
            </p>

            <Link href="/signup" className="btn-primary" style={{ fontSize: "0.9375rem", padding: "0.625rem 1.375rem" }}>
              Start tracking deals
            </Link>
          </div>

          {/* Right: Product demo card */}
          <div style={{ width: "100%" }}>
            <ScopeDemoCard />
          </div>
        </div>
      </div>

      <style>{`
        @media (min-width: 900px) {
          .hero-grid {
            grid-template-columns: 52% 48% !important;
            align-items: center !important;
          }
        }
      `}</style>
    </section>
  );
}

/* ─── Product Demo Card ─────────────────────────────────── */
function ScopeDemoCard() {
  const agreed = [
    "60-second mid-roll mention",
    "One brand card at end screen",
    "Link in description for 30 days",
  ];

  const requested = [
    "60-second mid-roll mention",
    "One brand card at end screen",
    "Link in description for 30 days",
    { text: "Dedicated intro segment (15 sec)", flagged: true },
    { text: "Pin comment with promo code", flagged: true },
    { text: "Story post on community tab", flagged: true },
  ];

  return (
    <div
      style={{
        border: "1px solid var(--border)",
        borderRadius: "16px",
        overflow: "hidden",
        background: "var(--bg)",
      }}
    >
      {/* Card header */}
      <div
        style={{
          padding: "0.875rem 1.25rem",
          borderBottom: "1px solid var(--border)",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          background: "var(--bg-subtle)",
        }}
      >
        <div>
          <div
            style={{
              fontSize: "0.8125rem",
              fontWeight: 600,
              color: "var(--text)",
              marginBottom: "0.1rem",
            }}
          >
            NordVPN - March Integration
          </div>
          <div style={{ fontSize: "0.75rem", color: "var(--text-faint)" }}>
            Signed Feb 14 &middot; $4,200
          </div>
        </div>
        <span className="badge-danger">3 flags</span>
      </div>

      {/* Two-column scope comparison */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
        }}
      >
        {/* Agreed column */}
        <div
          style={{
            padding: "1rem 1.25rem",
            borderRight: "1px solid var(--border)",
          }}
        >
          <div
            style={{
              fontSize: "0.6875rem",
              fontWeight: 600,
              color: "var(--text-faint)",
              letterSpacing: "0.08em",
              textTransform: "uppercase",
              marginBottom: "0.75rem",
            }}
          >
            Agreed scope
          </div>
          <ul style={{ listStyle: "none", display: "flex", flexDirection: "column", gap: "0.6rem" }}>
            {agreed.map((item, i) => (
              <li key={i} style={{ display: "flex", alignItems: "flex-start", gap: "0.5rem" }}>
                <CheckIcon />
                <span style={{ fontSize: "0.8125rem", color: "var(--text-muted)", lineHeight: 1.4 }}>
                  {item}
                </span>
              </li>
            ))}
          </ul>
        </div>

        {/* Requested column */}
        <div style={{ padding: "1rem 1.25rem" }}>
          <div
            style={{
              fontSize: "0.6875rem",
              fontWeight: 600,
              color: "var(--text-faint)",
              letterSpacing: "0.08em",
              textTransform: "uppercase",
              marginBottom: "0.75rem",
            }}
          >
            They&apos;re asking for
          </div>
          <ul style={{ listStyle: "none", display: "flex", flexDirection: "column", gap: "0.6rem" }}>
            {requested.map((item, i) => {
              const isObj = typeof item === "object";
              return (
                <li key={i} style={{ display: "flex", alignItems: "flex-start", gap: "0.5rem" }}>
                  {isObj ? <FlagIcon /> : <CheckIcon />}
                  <span
                    style={{
                      fontSize: "0.8125rem",
                      color: isObj ? "var(--danger)" : "var(--text-muted)",
                      lineHeight: 1.4,
                      fontWeight: isObj ? 500 : 400,
                    }}
                  >
                    {isObj ? item.text : item}
                  </span>
                </li>
              );
            })}
          </ul>
        </div>
      </div>

      {/* Alert strip */}
      <div
        style={{
          margin: "0 1.25rem 1.25rem",
          padding: "0.75rem 1rem",
          background: "var(--danger-light)",
          borderRadius: "8px",
          display: "flex",
          alignItems: "flex-start",
          gap: "0.5rem",
        }}
      >
        <svg width="14" height="14" viewBox="0 0 16 16" fill="none" style={{ flexShrink: 0, marginTop: "1px" }}>
          <path d="M8 2L14.5 13.5H1.5L8 2Z" stroke="#EF4444" strokeWidth="1.5" strokeLinejoin="round" />
          <path d="M8 7V9.5" stroke="#EF4444" strokeWidth="1.5" strokeLinecap="round" />
          <circle cx="8" cy="11.5" r="0.75" fill="#EF4444" />
        </svg>
        <span style={{ fontSize: "0.8125rem", color: "var(--danger)", fontWeight: 500, lineHeight: 1.4 }}>
          3 items outside agreed scope. Review before responding.
        </span>
      </div>
    </div>
  );
}

function CheckIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" style={{ flexShrink: 0, marginTop: "1px" }}>
      <circle cx="8" cy="8" r="6.5" stroke="#059669" strokeWidth="1.25" />
      <path d="M5.5 8.25L7.25 10L10.5 6.5" stroke="#059669" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function FlagIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" style={{ flexShrink: 0, marginTop: "1px" }}>
      <circle cx="8" cy="8" r="6.5" stroke="#EF4444" strokeWidth="1.25" />
      <path d="M8 5V8.5" stroke="#EF4444" strokeWidth="1.25" strokeLinecap="round" />
      <circle cx="8" cy="10.5" r="0.75" fill="#EF4444" />
    </svg>
  );
}

/* ─── How It Works ──────────────────────────────────────── */
function HowItWorksSection() {
  const steps = [
    {
      number: "01",
      title: "Log the deal",
      body: "Add a sponsor, set the agreed deliverables, and record the fee. Takes two minutes.",
    },
    {
      number: "02",
      title: "Track requests",
      body: "As the sponsor sends briefs and revisions, log what they are asking for against what was agreed.",
    },
    {
      number: "03",
      title: "Catch the creep",
      body: "Clauso flags anything outside your contract so you can decide whether to charge more or push back.",
    },
  ];

  return (
    <section style={{ padding: "5rem 0", borderBottom: "1px solid var(--border)" }}>
      <div className="page-container">
        {/* Section label — left anchored, not centered */}
        <div style={{ marginBottom: "3rem" }}>
          <div
            style={{
              fontSize: "0.75rem",
              fontWeight: 600,
              color: "var(--text-faint)",
              letterSpacing: "0.1em",
              textTransform: "uppercase",
              marginBottom: "0.5rem",
            }}
          >
            How it works
          </div>
          <h2 style={{ maxWidth: "400px" }}>
            Built around how sponsorships actually go wrong.
          </h2>
        </div>

        {/* Steps grid */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))",
            gap: "0",
            border: "1px solid var(--border)",
            borderRadius: "16px",
            overflow: "hidden",
          }}
        >
          {steps.map((step, i) => (
            <div
              key={i}
              style={{
                padding: "1.75rem",
                borderRight: i < steps.length - 1 ? "1px solid var(--border)" : "none",
                borderBottom: "none",
              }}
              className={`step-card step-${i}`}
            >
              <span
                style={{
                  display: "block",
                  fontSize: "0.6875rem",
                  fontWeight: 700,
                  color: "var(--accent)",
                  letterSpacing: "0.1em",
                  marginBottom: "0.875rem",
                }}
              >
                {step.number}
              </span>
              <h3 style={{ marginBottom: "0.5rem" }}>{step.title}</h3>
              <p style={{ fontSize: "0.875rem", lineHeight: 1.65 }}>{step.body}</p>
            </div>
          ))}
        </div>
      </div>

      <style>{`
        @media (max-width: 767px) {
          .step-card {
            border-right: none !important;
            border-bottom: 1px solid var(--border) !important;
          }
          .step-2 {
            border-bottom: none !important;
          }
        }
      `}</style>
    </section>
  );
}

/* ─── Bottom CTA ────────────────────────────────────────── */
function BottomCTA() {
  return (
    <section style={{ padding: "5rem 0" }}>
      <div className="page-container">
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            gap: "1.5rem",
          }}
          className="cta-inner"
        >
          <div>
            <h2 style={{ maxWidth: "480px" }}>
              Know exactly what you agreed to, every time.
            </h2>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: "1rem", flexWrap: "wrap" }}>
            <Link
              href="/signup"
              className="btn-primary"
              style={{ fontSize: "0.9375rem", padding: "0.625rem 1.375rem" }}
            >
              Create a free account
            </Link>
            <span style={{ fontSize: "0.8125rem", color: "var(--text-faint)" }}>
              No credit card needed.
            </span>
          </div>
        </div>
      </div>

      <style>{`
        @media (min-width: 768px) {
          .cta-inner {
            flex-direction: row !important;
            align-items: center !important;
            justify-content: space-between !important;
          }
        }
      `}</style>
    </section>
  );
}
