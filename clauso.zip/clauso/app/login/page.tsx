"use client";

import Link from "next/link";
import { useState } from "react";
import { AuthShell } from "@/components/AuthShell";
import type { Metadata } from "next";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  return (
    <AuthShell
      title="Welcome back"
      description="Log in to your Clauso account."
      footer={
        <span style={{ fontSize: "0.8125rem", color: "var(--text-faint)" }}>
          No account?{" "}
          <Link
            href="/signup"
            style={{ color: "var(--accent)", fontWeight: 500 }}
          >
            Sign up
          </Link>
        </span>
      }
    >
      <form onSubmit={(e) => e.preventDefault()}>
        <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
          <div>
            <label className="label" htmlFor="email">
              Email
            </label>
            <input
              id="email"
              type="email"
              className="input"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="email"
            />
          </div>

          <div>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                marginBottom: "0.35rem",
              }}
            >
              <label
                className="label"
                htmlFor="password"
                style={{ marginBottom: 0 }}
              >
                Password
              </label>
              <Link
                href="/reset-password"
                style={{
                  fontSize: "0.8125rem",
                  color: "var(--text-faint)",
                  transition: "color 0.15s",
                }}
              >
                Forgot?
              </Link>
            </div>
            <input
              id="password"
              type="password"
              className="input"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="current-password"
            />
          </div>

          <button
            type="submit"
            className="btn-primary"
            style={{ width: "100%", justifyContent: "center", marginTop: "0.25rem" }}
          >
            Log in
          </button>
        </div>
      </form>
    </AuthShell>
  );
}
