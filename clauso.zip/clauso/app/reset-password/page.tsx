"use client";

import Link from "next/link";
import { useState } from "react";
import { AuthShell } from "@/components/AuthShell";

export default function ResetPasswordPage() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSent(true);
  }

  return (
    <AuthShell
      title="Reset your password"
      description="Enter your email and we will send a reset link."
      footer={
        <span style={{ fontSize: "0.8125rem", color: "var(--text-faint)" }}>
          <Link href="/login" style={{ color: "var(--accent)", fontWeight: 500 }}>
            Back to log in
          </Link>
        </span>
      }
    >
      {sent ? (
        <div
          style={{
            padding: "1rem",
            background: "var(--accent-light)",
            borderRadius: "8px",
            display: "flex",
            alignItems: "flex-start",
            gap: "0.625rem",
          }}
        >
          <svg
            width="16"
            height="16"
            viewBox="0 0 16 16"
            fill="none"
            style={{ flexShrink: 0, marginTop: "1px" }}
          >
            <circle cx="8" cy="8" r="6.5" stroke="#059669" strokeWidth="1.25" />
            <path
              d="M5.5 8.25L7.25 10L10.5 6.5"
              stroke="#059669"
              strokeWidth="1.25"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
          <div>
            <p
              style={{
                fontSize: "0.875rem",
                color: "var(--accent-dark)",
                fontWeight: 500,
                marginBottom: "0.15rem",
              }}
            >
              Check your inbox
            </p>
            <p style={{ fontSize: "0.8125rem", color: "var(--accent-dark)", opacity: 0.8 }}>
              If an account exists for {email}, a reset link is on its way.
            </p>
          </div>
        </div>
      ) : (
        <form onSubmit={handleSubmit}>
          <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
            <div>
              <label className="label" htmlFor="email">
                Email
              </label>
              <input
                id="email"
                type="email"
                className="input"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                autoComplete="email"
                required
              />
            </div>

            <button
              type="submit"
              className="btn-primary"
              style={{
                width: "100%",
                justifyContent: "center",
                marginTop: "0.25rem",
              }}
            >
              Send reset link
            </button>
          </div>
        </form>
      )}
    </AuthShell>
  );
}
